<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        $this->load->model('M_laporan');
        setlocale(LC_ALL, 'id_id');
        setlocale(LC_TIME, 'id_ID.utf8');
    }    
    // akses admin
        public function index() // read
        {
            if($this->session->userdata('role') === 'Admin')
            {
                $data['judul'] = 'Data Laporan';
                $data['transaksi'] = $this->M_laporan->daftartransaksi(); // data transaksi
                $this->template->load('template','V_laporan/laporan',$data);
            }
            else
            {
                $this->load->view('block');
            }
        }
    // akses kasir
        public function kasir() // read
        {
            if($this->session->userdata('role') === 'Kasir')
            {
                $data['judul'] = 'Data Laporan';
                $data['transaksi'] = $this->M_laporan->daftartransaksi(); // data transaksi
                $this->template->load('template','V_laporan/laporan',$data);
            }
            else
            {
                $this->load->view('block');
            }
        }
    // akses owner
        public function owner() // read
        {
            if($this->session->userdata('role') === 'Owner')
            {
                $data['judul'] = 'Data Laporan';
                $data['transaksi'] = $this->M_laporan->daftartransaksi(); // data transaksi
                $this->template->load('template','V_laporan/laporan',$data);
            }
            else
            {
                $this->load->view('block');
            }
        }
}
