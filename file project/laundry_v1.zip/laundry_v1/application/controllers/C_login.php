<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		// $this->load->model('M_login');
	}
	public function index()
	{
		$data['judul'] = 'Masuk';
		$this->load->view('V_formlogin',$data);
	}
    public function keluar()
    {
        $this->session->sess_destroy();
        redirect('C_login');
    }
	public function masuk()
	{
		// validasi
		$this->form_validation->set_rules('username', 'Username', 'trim|required',['required' => 'Kolom tidak boleh kosong!']); 
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[3]',['required' => 'Kolom tidak boleh kosong!','min_length' => 'Kata sandi harus antara 3 dan 10 karakter!']);

		$username = $this->input->post('username',TRUE);
		$password = md5($this->input->post('password',TRUE));
		$validate = $this->M_login->validate($username,$password);
		if($this->form_validation->run() != false)
		{

			if ($validate->num_rows() > 0) 
			{
				$data  = $validate->row_array();
				$id_user    = $data['id_user'];
				$nama  = $data['nama'];
				$username = $data['username'];
				$role  = $data['role'];
				$sesdata = array(
					'id_user' => $id_user,
					'nama' => $nama,
					'username' => $username,
					'role' => $role,
					'status_login' => TRUE
				);
				$this->session->set_userdata($sesdata);
				if($role === 'Admin')
				{
					redirect('C_beranda');
				}
				elseif($role === 'Kasir')
				{
					redirect('C_pelanggan/kasir');
				}
				else
				{
					redirect('C_laporan/owner');
				}
			}
			else
			{
				 $this->session->set_flashdata
				 ('message', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
				 Email atau Password salah!
				 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				 </div>');
				redirect('C_login');
			}

		}
		else
		{
			$data['judul'] = 'Masuk';
			$this->load->view('V_formlogin',$data);
		}

	}
}
