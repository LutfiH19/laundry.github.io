<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_transaksi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        // $this->load->library('cart');
        $this->load->model('M_transaksi');
        date_default_timezone_set("Asia/Bangkok");
    }
    public function kilo() // javascript kalkulasi
    {
      $kilo = $_POST['jml_kilo']; // jml_kilo = total_berat
      $paket = $this->M_transaksi->showall('tb_paket',"WHERE id_paket = '$_POST[paket]' ")->row();
      if ($_POST['jml_kilo'] == "") {
        $total="";
      }else{
        $total = $paket->harga * $kilo;
      }
      echo $total;
    }
    // akses admin
        // read
          public function index() 
          {
              if($this->session->userdata('role') === 'Admin')
              {
                  $data['judul'] = 'Data Transaksi';
                  $data['transaksi'] = $this->M_transaksi->daftartransaksi(); // data transaksi
                  $this->template->load('template','V_transaksi/transaksi',$data);
              }
              else
              {
                  $this->load->view('block'); // blokir akses
              }
          }

        // create
          public function add()
          {
              // validasi
                $this->form_validation->set_rules('id_member','Pelanggan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('id_paket','Paket','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jml_kilo','Jumlah kilo','required|trim|greater_than_equal_to[1]|less_than_equal_to[30]',
                ['required' => 'Kolom tidak boleh kosong!',
                'greater_than_equal_to' => 'Minimal 1 kilogram!',
                'less_than_equal_to' => 'Maksimal 30 kilogram!']);

                $this->form_validation->set_rules('biaya_tambahan','Biaya Tambahan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('diskon','Diskon','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('bayar','Bayar','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
      
      
              if ($this->form_validation->run() == FALSE)
              {
                $data['judul'] = 'Tambah Data Transaksi';
                $data['paket'] = $this->M_transaksi->daftarpaket(); // looping all data paket
                $data['pelanggan'] = $this->M_transaksi->daftarpelanggan(); // looping all data member
                // -------------------------No otomatis-------------------------- // 
                $qr = $this->M_transaksi->no()->row_array(); // no otomatis
                $kode = $qr['kode'];
                $nu = (int) substr($kode, 6,9);
                $nu++;
                $tgl = date('y');
                $data['no'] = "INV".$tgl.sprintf('%04s',$nu);
                // -------------------------No otomatis-------------------------- // 
                $this->template->load('template','V_transaksi/tambah',$data);

              }
              else
              {
                $this->M_transaksi->add_data();
                $this->session->set_flashdata
                ('pesan_transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Data transaksi berhasil ditambahkan!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>');
                redirect('C_transaksi');
              }
          }
        
        // update
          public function ubah($id_transaksi)
          {
              // validasi
                $this->form_validation->set_rules('id_member','Pelanggan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('id_paket','Paket','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jml_kilo','Jumlah kilo','required|trim|greater_than_equal_to[1]|less_than_equal_to[30]',
                ['required' => 'Kolom tidak boleh kosong!',
                'greater_than_equal_to' => 'Minimal 1 kilogram!',
                'less_than_equal_to' => 'Maksimal 30 kilogram!']);

                $this->form_validation->set_rules('biaya_tambahan','Biaya Tambahan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('','Tanggal Ambil','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('diskon','Diskon','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('bayar','Bayar','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
    
              if ($this->form_validation->run() == FALSE)
              {
                $data['judul'] = 'Detail Data Transaksi';

                $data['trans'] = $this->M_transaksi->edit($id_transaksi); // edit 1 data with id
                $data['paket'] = $this->M_transaksi->daftarpaket(); // looping all data paket
                $data['paket2'] = $this->M_transaksi->daftarpaket2($id_transaksi); // show 1 data paket only with id

                $data['pelanggan'] = $this->M_transaksi->daftarpelanggan(); // looping all data pelanggan
                $data['pelanggan2'] = $this->M_transaksi->daftarpelanggan2($id_transaksi); // show 1 data member only with id
                // -------------------------No otomatis-------------------------- // 
                $qr = $this->M_transaksi->no()->row_array(); // no otomatis
                $kode = $qr['kode'];
                $nu = (int) substr($kode, 6,9);
                $nu++;
                $tgl = date('y');
                $data['no'] = "INV".$tgl.sprintf('%04s',$nu);
                // -------------------------No otomatis-------------------------- // 
                $this->template->load('template','V_transaksi/perbarui',$data);

              }
              else
              {
                $this->M_transaksi->update($id_transaksi);
                $this->session->set_flashdata
                ('pesan_transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Data transaksi berhasil diperbarui!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>');
                redirect('C_transaksi');
              }
          }

    // akses kasir
        //  read
          public function kasir()
          {
              if($this->session->userdata('role') === 'Kasir')
              {
                  $data['judul'] = 'Data Transaksi';
                  $data['transaksiK'] = $this->M_transaksi->daftartransaksiK(); // data transaksi
                  $this->template->load('template','V_transaksi/transaksiK',$data);
              }
              else
              {
                  $this->load->view('block'); // blokir akses
              }
          }
        
        // create
          public function addK()
          {
              // validasi
                $this->form_validation->set_rules('id_member','Pelanggan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('id_paket','Paket','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jml_kilo','Jumlah kilo','required|trim|greater_than_equal_to[1]|less_than_equal_to[30]',
                ['required' => 'Kolom tidak boleh kosong!',
                'greater_than_equal_to' => 'Minimal 1 kilogram!',
                'less_than_equal_to' => 'Maksimal 30 kilogram!']);

                $this->form_validation->set_rules('biaya_tambahan','Biaya Tambahan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('diskon','Diskon','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('bayar','Bayar','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
      
      
              if ($this->form_validation->run() == FALSE)
              {
                $data['judul'] = 'Tambah Data Transaksi';
                $data['paket'] = $this->M_transaksi->daftarpaket(); // looping all data paket
                $data['pelanggan'] = $this->M_transaksi->daftarpelanggan(); // looping all data member
                // -------------------------No otomatis-------------------------- // 
                $qr = $this->M_transaksi->no()->row_array(); // no otomatis
                $kode = $qr['kode'];
                $nu = (int) substr($kode, 6,9);
                $nu++;
                $tgl = date('y');
                $data['no'] = "INV".$tgl.sprintf('%04s',$nu);
                // -------------------------No otomatis-------------------------- // 
                $this->template->load('template','V_transaksi/tambahK',$data);

              }
              else
              {
                $this->M_transaksi->add_dataK();
                $this->session->set_flashdata
                ('pesan_transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Data transaksi berhasil ditambahkan!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>');
                redirect('C_transaksi/kasir');
              }
          }

        // update
          public function ubahK($id_transaksi)
          {
              // validasi
                $this->form_validation->set_rules('id_member','Pelanggan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('id_paket','Paket','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jml_kilo','Jumlah kilo','required|trim|greater_than_equal_to[1]|less_than_equal_to[30]',
                ['required' => 'Kolom tidak boleh kosong!',
                'greater_than_equal_to' => 'Minimal 1 kilogram!',
                'less_than_equal_to' => 'Maksimal 30 kilogram!']);

                $this->form_validation->set_rules('biaya_tambahan','Biaya Tambahan','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('','Tanggal Ambil','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('diskon','Diskon','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
                
                $this->form_validation->set_rules('bayar','Bayar','required|trim',
                ['required' => 'Kolom tidak boleh kosong!']);
    
              if ($this->form_validation->run() == FALSE)
              {
                $data['judul'] = 'Detail Data Transaksi';

                $data['transK'] = $this->M_transaksi->editK($id_transaksi); // edit 1 data with id
                $data['paket'] = $this->M_transaksi->daftarpaket(); // looping all data paket
                $data['paket2K'] = $this->M_transaksi->daftarpaket2K($id_transaksi); // show 1 data paket only with id

                // $data['pelanggan'] = $this->M_transaksi->daftarpelanggan(); // looping all data pelanggan
                $data['pelanggan2K'] = $this->M_transaksi->daftarpelanggan2K($id_transaksi); // show 1 data member only with id
                // -------------------------No otomatis-------------------------- // 
                $qr = $this->M_transaksi->no()->row_array(); // no otomatis
                $kode = $qr['kode'];
                $nu = (int) substr($kode, 6,9);
                $nu++;
                $tgl = date('y');
                $data['no'] = "INV".$tgl.sprintf('%04s',$nu);
                // -------------------------No otomatis-------------------------- // 
                $this->template->load('template','V_transaksi/perbaruiK',$data);

              }
              else
              {
                $this->M_transaksi->updateK($id_transaksi);
                $this->session->set_flashdata
                ('pesan_transaksi', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Data transaksi berhasil diperbarui!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>');
                redirect('C_transaksi/kasir');
              }
          }


}
