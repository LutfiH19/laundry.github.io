<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_outlet  extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        $this->load->model('M_outlet');
    }    
    // akses admin
      public function index() // read
      {
          if($this->session->userdata('role') === 'Admin')
          {
              $data['judul'] = 'Data Outlet';
              $data['outlet'] = $this->M_outlet->tampil_data(); // filter admin
              $this->template->load('template','V_outlet/outlet',$data);
          }
          else
          {
            $this->load->view('block');
          }
      }

      // create
        public function add()
        {
            // validasi
              $this->form_validation->set_rules('nama_outlet','Nama Outlet','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('id_user','Nama Pengguna','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('alamat','Alamat','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('tlp','Telepon','required|trim|min_length[11]|max_length[12]',
              ['required' => 'Kolom tidak boleh kosong!',
              'min_length' => 'Minimal 11 angka!',
              'max_length' => 'Maksimal 12 angka!']);

            if ($this->form_validation->run() == FALSE)
            {
              $data['judul'] = 'Tambah Data Outlet';
              $data['pengguna'] = $this->M_outlet->daftarpengguna(); // looping nama pengguna (all)
              $this->template->load('template','V_outlet/tambah',$data);
            }
            else
            {
              $this->M_outlet->add_data();
              $this->session->set_flashdata
              ('pesan_outlet', '<div class="alert alert-success alert-dismissible fade show" role="alert">
              Data outlet berhasil ditambahkan!
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>');
              redirect('C_outlet');
            }
        }

      // update 
        public function ubah($id_outlet)
        {
            // validasi
              $this->form_validation->set_rules('nama_outlet','Nama Outlet','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('id_user','Nama Pengguna','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('alamat','Alamat','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('tlp','Telepon','required|trim|min_length[11]|max_length[12]',
              ['required' => 'Kolom tidak boleh kosong!',
              'min_length' => 'Minimal 11 angka!',
              'max_length' => 'Maksimal 12 angka!']);

            if ($this->form_validation->run() == FALSE)
            {
              $data['judul'] = 'Perbarui Data Outlet';
              $data['outlet'] = $this->M_outlet->edit($id_outlet); // lopping edit tb_outlet dengan id
              $data['pengguna2'] = $this->M_outlet->daftarpengguna2(); // looping nama pengguna
              $data['pengguna3'] = $this->M_outlet->daftarpengguna3($id_outlet); // looping nama pengguna dengan id
              $this->template->load('template','V_outlet/perbarui',$data);
            }
            else
            {
              $this->M_outlet->update($id_outlet);
              $this->session->set_flashdata
              ('pesan_outlet', '<div class="alert alert-success alert-dismissible fade show" role="alert">
              Data outlet berhasil diperbarui!
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>');
              redirect('C_outlet');
            }
        }

      // delete 
        public function drop()
        {
            $id_outlet = $this->input->post('hapus');
            $this->M_outlet->dropped($id_outlet);
            $this->session->set_flashdata
            ('pesan_outlet', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Data outlet berhasil dihapus!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_outlet');
        }
    
}
