<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_paket extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        $this->load->model('M_paket');
    }    
    // akses admin
      public function index() // read
      {
          if($this->session->userdata('role') === 'Admin')
          {
              $data['judul'] = 'Data Paket';
              $data['paket'] = $this->M_paket->tampil_data(); 
              $this->template->load('template','V_paket/paket',$data);
          }
          else
          {
            $this->load->view('block');
          }
      }

      // create
        public function add()
        {
            // validasi
              $this->form_validation->set_rules('nama_paket','Nama Paket','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('jenis_paket','Jenis Paket','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('harga','Harga','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('id_outlet','Outlet','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

            if ($this->form_validation->run() == FALSE)
            {
              $data['judul'] = 'Tambah Data Paket';
              $data['outlet'] = $this->M_paket->daftaroutlet(); // looping outlet
              $this->template->load('template','V_paket/tambah',$data);
            }
            else
            {
              $this->M_paket->add_data();
              // var_dump($this->M_paket->add_data());
              // die();
              $this->session->set_flashdata
              ('pesan_paket', '<div class="alert alert-success alert-dismissible fade show" role="alert">
              Data paket berhasil ditambahkan!
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>');
              redirect('C_paket');
            }
        }

      // update
      public function ubah($id_paket)
        {
            // validasi
              $this->form_validation->set_rules('nama_paket','Nama Paket','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('jenis_paket','Jenis Paket','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('harga','Harga','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

              $this->form_validation->set_rules('id_outlet','Outlet','required|trim',
              ['required' => 'Kolom tidak boleh kosong!']);

            if ($this->form_validation->run() == FALSE)
            {
              $data['judul'] = 'Perbarui Data Paket';
              $data['paket'] = $this->M_paket->edit($id_paket);
              $data['outlet2'] = $this->M_paket->daftaroutlet2(); // looping outlet
              $data['outlet3'] = $this->M_paket->daftaroutlet3($id_paket); // looping outlet dengan id
              $this->template->load('template','V_paket/perbarui',$data);
            }
            else
            {
              $this->M_paket->update($id_paket);
              $this->session->set_flashdata
              ('pesan_paket', '<div class="alert alert-primary alert-dismissible fade show" role="alert">
              Data paket berhasil diperbarui!
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>');
              redirect('C_paket');
            }
        }

      // delete
        public function drop()
        {
          $id_paket = $this->input->post('hapus');
          $this->M_paket->dropped($id_paket);
          $this->session->set_flashdata
          ('pesan_paket', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
          Data paket berhasil dihapus!
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          redirect('C_paket');
        }

}
