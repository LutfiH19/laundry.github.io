<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_user extends CI_Controller
{
    // private $tabel_user = "tb_user";
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        $this->load->model('M_user');
    }    
    // akses admin
      public function index() // read
      {
        if($this->session->userdata('role') === 'Admin')
        {
            $data['judul'] = 'Data Pengguna';
            $data['userv'] = $this->M_user->tampil_data(); // tampil data kecuali admin
            $this->template->load('template','V_user/user',$data);
        }
        else
        {
            $this->load->view('block'); // blokir akses
        }
      }

      // create
      public function add()
      {
        // validasi
          $this->form_validation->set_rules('nama','Nama','required|trim|min_length[3]|max_length[20]',
          ['required' => 'Kolom tidak boleh kosong!',
          'min_length' => 'Minimal 3 huruf!',
          'max_length' => 'Maksimal 20 huruf!']);

          $this->form_validation->set_rules('username','Username','required|trim|is_unique[tb_user.username]',
          ['required' => 'Kolom tidak boleh kosong!',
          'is_unique' => 'Username sudah terdaftar!']);

          $this->form_validation->set_rules('password','Password','required|trim|min_length[3]|max_length[12]',
          ['required' => 'Kolom tidak boleh kosong!',
          'min_length' => 'Minimal 3 karakter!',
          'max_length' => 'Maksimal 12 karakter!']);

          $this->form_validation->set_rules('role','Role','required',
          ['required' => 'Kolom tidak boleh kosong!']);


        if ($this->form_validation->run() == FALSE)
        {
          $data['judul'] = 'Tambah Data Pengguna';
          $this->template->load('template','V_user/tambah',$data);
        }
        else
        {
          $this->M_user->add_data();
          $this->session->set_flashdata
          ('pesan_user', '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data pengguna berhasil ditambahkan!
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          redirect('C_user');
        }
      }

      // update 
      public function ubah($id_user)
      {
        // validasi
          $this->form_validation->set_rules('nama','Nama','required|trim|min_length[3]|max_length[20]',
          ['required' => 'Kolom tidak boleh kosong!',
          'min_length' => 'Minimal 3 huruf!',
          'max_length' => 'Maksimal 20 huruf!']);

          $this->form_validation->set_rules('username','Username','required|trim',
          ['required' => 'Kolom tidak boleh kosong!']);

          // $this->form_validation->set_rules('password','Password','required|trim|min_length[3]|max_length[12]',
          // ['required' => 'Kolom tidak boleh kosong!',
          // 'min_length' => 'Minimal 3 karakter!',
          // 'max_length' => 'Maksimal 12 karakter!']);

          $this->form_validation->set_rules('role','Role','required',
          ['required' => 'Kolom tidak boleh kosong!']);


        if ($this->form_validation->run() == FALSE)
        {
          $data['judul'] = 'Perbarui Data Pengguna';
          $data['user'] = $this->M_user->edit($id_user); // looping edit data tb_user dengan id
          $this->template->load('template','V_user/perbarui',$data);
        }
        else
        {
          $this->M_user->update($id_user);
          $this->session->set_flashdata
          ('pesan_user', '<div class="alert alert-success alert-dismissible fade show" role="alert">
          Data pengguna berhasil diperbarui!
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>');
          redirect('C_user');
        }
      }

      // delete 
      public function drop()
      {
        $id_user = $this->input->post('hapus');
        $this->M_user->dropped($id_user);
        $this->session->set_flashdata
        ('pesan_user', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        Data pengguna berhasil dihapus!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>');
        redirect('C_user');
      }


}

