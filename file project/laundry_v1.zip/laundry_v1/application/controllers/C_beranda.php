<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_beranda extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        $this->load->model('M_beranda');
    }
    // akses admin
        // read
            public function index()
            {
                if($this->session->userdata('role') === 'Admin')
                {
                    $data['judul'] = 'Beranda';

                    $data['transaksi'] = $this->M_beranda->daftartransaksi(); // data transaksi

                    $data['jumlah_outlet'] = $this->M_beranda->j_outlet();
                    $data['jumlah_pelanggan'] = $this->M_beranda->j_pelanggan();
                    $data['jumlah_transaksi'] = $this->M_beranda->j_transaksi();
                    $data['total_penghasilan'] = $this->M_beranda->t_penghasilan();

                    $this->template->load('template','V_beranda/beranda',$data);
                }
                else
                {
                    $this->load->view('block');
                }
            }

    // owner
        // read
        public function owner()
        {
            if($this->session->userdata('role') === 'Owner')
            {
                $data['judul'] = 'Beranda';

                $data['transaksi'] = $this->M_beranda->daftartransaksi(); // data transaksi

                $data['jumlah_outlet'] = $this->M_beranda->j_outlet();
                $data['jumlah_pelanggan'] = $this->M_beranda->j_pelanggan();
                $data['jumlah_transaksi'] = $this->M_beranda->j_transaksi();
                $data['total_penghasilan'] = $this->M_beranda->t_penghasilan();

                $this->template->load('template','V_beranda/berandaO',$data);
            }
            else
            {
                $this->load->view('block');
            }
        }

}
