<?php
defined('BASEPATH') or exit('No direct script access allowed');
class C_pelanggan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('status_login') !== TRUE){
          redirect('C_login');
        }
        $this->load->model('M_pelanggan');
    }    
    // akses admin
        public function index() // read
        {
            if($this->session->userdata('role') === 'Admin')
            {
                $data['judul'] = 'Data Pelanggan';
                $data['pelanggan'] = $this->M_pelanggan->tampil_data(); 
                $this->template->load('template','V_pelanggan/pelanggan',$data);
            }
            else
            {
                $this->load->view('block'); // blokir akses
            }
        }

        // create
        public function add()
        {
            // validasi
                $this->form_validation->set_rules('nama','Nama','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('alamat','Alamat','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('tlp','Telepon','required|trim|min_length[11]|max_length[12]',
                ['required' => 'kolom tidak boleh kosong!',
                'min_length' => 'Minimal 11 angka!',
                'max_length' => 'Maksimal 12 angka!']);

            if ($this->form_validation->run() == FALSE)
            {
            $data['judul'] = 'Tambah Data Pelanggan';
            $this->template->load('template','V_pelanggan/tambah',$data);
            }
            else
            {
            $this->M_pelanggan->add_data();
            $this->session->set_flashdata
            ('pesan_pelanggan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data pelanggan berhasil ditambahkan!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_pelanggan');
            }
        }

        // update 
        public function ubah($id_member)
        {
            // validasi
                $this->form_validation->set_rules('nama','Nama','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('alamat','Alamat','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('tlp','Telepon','required|trim|min_length[11]|max_length[12]',
                ['required' => 'kolom tidak boleh kosong!',
                'min_length' => 'Minimal 11 angka!',
                'max_length' => 'Maksimal 12 angka!']);


            if ($this->form_validation->run() == FALSE)
            {
            $data['judul'] = 'Perbarui Data Pelanggan';
            $data['pelanggan'] = $this->M_pelanggan->edit($id_member); // loop edit data tb_member dengan id
            $this->template->load('template','V_pelanggan/perbarui',$data);
            }
            else
            {
            $this->M_pelanggan->update($id_member);
            $this->session->set_flashdata
            ('pesan_pelanggan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data pelanggan berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_pelanggan');
            }
        }

        // delete 
        public function drop()
        {
            $id_member = $this->input->post('hapus');
            $this->M_pelanggan->dropped($id_member);
            $this->session->set_flashdata
            ('pesan_pelanggan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Data pelanggan berhasil dihapus!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_pelanggan');

        }

    // akses kasir
        public function kasir() // read
        {
            if($this->session->userdata('role') === 'Kasir')
            {
                $data['judul'] = 'Data Pelanggan';
                $data['pelanggan'] = $this->M_pelanggan->tampil_data2(); // show data table 
                $this->template->load('template','V_pelanggan/pelanggan2',$data);
            }
            else
            {
                $this->load->view('block');
            }
        }

        // create
        public function add2()
        {
            // validasi
                $this->form_validation->set_rules('nama','Nama','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('alamat','Alamat','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('tlp','Telepon','required|trim|min_length[11]|max_length[12]',
                ['required' => 'kolom tidak boleh kosong!',
                'min_length' => 'Minimal 11 angka!',
                'max_length' => 'Maksimal 12 angka!']);

            if ($this->form_validation->run() == FALSE)
            {
            $data['judul'] = 'Tambah Data Pelanggan';
            $this->template->load('template','V_pelanggan/tambah2',$data);
            }
            else
            {
            $this->M_pelanggan->add_data2();
            $this->session->set_flashdata
            ('pesan_pelanggan2', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data pelanggan berhasil ditambahkan!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_pelanggan/kasir');
            }
        }

        // update 
        public function ubah2($id_member)
        {
            // validasi
                $this->form_validation->set_rules('nama','Nama','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('alamat','Alamat','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required|trim',
                ['required' => 'kolom tidak boleh kosong!']);

                $this->form_validation->set_rules('tlp','Telepon','required|trim|min_length[11]|max_length[12]',
                ['required' => 'kolom tidak boleh kosong!',
                'min_length' => 'Minimal 11 angka!',
                'max_length' => 'Maksimal 12 angka!']);


            if ($this->form_validation->run() == FALSE)
            {
            $data['judul'] = 'Perbarui Data Pelanggan';
            $data['pelanggan'] = $this->M_pelanggan->edit2($id_member); // loop edit data tb_member dengan id
            $this->template->load('template','V_pelanggan/perbarui2',$data);
            }
            else
            {
            $this->M_pelanggan->update2($id_member);
            $this->session->set_flashdata
            ('pesan_pelanggan2', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Data pelanggan berhasil diperbarui!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_pelanggan/kasir');
            }
        }

        // delete 
        public function drop2()
        {
            $id_member = $this->input->post('hapus');
            $this->M_pelanggan->dropped2($id_member);
            $this->session->set_flashdata
            ('pesan_pelanggan2', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            Data pelanggan berhasil dihapus!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>');
            redirect('C_pelanggan/kasir');

        }
    
}
