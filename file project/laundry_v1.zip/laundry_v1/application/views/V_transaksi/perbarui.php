<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><?= $judul; ?></h1>

             
            <!-- form -->
            <?= form_open("C_transaksi/ubah/". $trans['id_transaksi']);?>
            <div class="card card-shadow mb-4">
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Kode Pemesanan</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="no_trans" id="form-control" value="<?= $trans['no_trans'] ; ?>" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Operator</label>
                                <input type="text" class="form-control" name="operator" id="form-control" value="<?= $trans['operator']; ?>" readonly>
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Pelanggan</label>
                                <select class="form-control" name="id_member" id="form-control" readonly>
                                    <option value="<?= $pelanggan2['id_member']; ?>"> <?= $pelanggan2['nama']; ?> </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Tanggal Transaksi</label>
                                <input type="date" class="form-control" name="tgl_transaksi" value="<?= $trans['tgl_transaksi']; ?>" readonly>
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Tanggal Ambil</label>
                                <input type="date" class="form-control" name="tgl_ambil" value="<?= $trans['tgl_ambil']; ?>">
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Pilih Paket</label>
                                <select class="form-control" name="id_paket" id="id_paket">
                                    <option value="<?= $paket2['id_paket']; ?>"> <?= $paket2['nama_paket']; ?> ( Rp. <?= number_format($paket2['harga'],0,",",".") ; ?> )</option>
                                    <option value="">--</option>
                                    <?php foreach ($paket as $pkt) { ?>
                                        <option value="<?= $pkt['id_paket']; ?>"><?= $pkt['nama_paket']; ?> ( Rp. <?= number_format($pkt['harga'],0,",",".") ; ?> )</option>
                                    <?php } ; ?>
                                </select>
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Status</label>
                                <select class="form-control" name="status" id="form-control">
                                    <option value="<?= $trans['status'] ;?>"><?= $trans['status']; ?></option>
                                    <option value="">--</option>
                                    <option value="proses">Proses</option>
                                    <option value="selesai">Selesai</option>
                                    <option value="diambil">Diambil</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- name="" for send db -->
                    <!-- id="" for css/javascript -->
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Total</label>
                                <input type="number" class="form-control" id="total" name="totalpure" value="<?= $trans['totalpure']; ?>" readonly>
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Total Berat (kg)</label>
                                <input type="number" class="form-control" id="jml_kilo" onkeyup="kilo()" value="<?= $trans['jml_kilo']; ?>" name="jml_kilo">  <!-- onkeyup="kilo()" function javascript -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Biaya Tambahan</label>
                                <input type="number" class="form-control" name="biaya_tambahan" onkeyup="calculate()" value="<?= $trans['biaya_tambahan']; ?>" id="biaya_tambahan">
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Diskon(%)</label>
                                <input type="number" class="form-control" name="diskon" id="diskon" value="<?= $trans['diskon']; ?>" onkeyup="calculate()">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Grand Total</label>
                                <input type="number" class="form-control" id="grand_total" name="grand_total" value="<?= $trans['grand_total']; ?>" readonly>
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Bayar</label>
                                <input type="number" class="form-control" name="bayar" value="<?= $trans['bayar']; ?>" id="bayar" onkeyup="calculate()">
                                <?= form_error('password1', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Kembalian</label>
                                <input type="number" class="form-control" name="kembalian" id="kembalian" value="<?= $trans['kembalian']; ?>" readonly>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="card-footer">
                    <a class="btn btn-primary btn-sm" href="<?= base_url('C_transaksi'); ?>"><i class="fas fa-arrow-left"></i>&nbsp; Kembali</a>
                    <button type="reset" class="btn btn-danger btn-sm" value="Reset"><i class="fas fa-sync-alt"></i>&nbsp; Reset</button>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-plus"></i>&nbsp; Perbarui</button>
                    <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#cetak<?= $trans['id_transaksi'] ; ?>"><i class="fas fa-print"></i>&nbsp; Cetak</button>
                </div>
            </div>
            <?= form_close(); ?>
            
        </div>
    </div>
</div>
<!-- content -->

<!-- Modal print -->
    <div class="modal fade" id="cetak<?= $trans['id_transaksi'] ; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-print"></i>&nbsp;  Cetak Data Transaksi !</h5>
            </div>
            <div class="modal-body">
                <div class="table-responsive" id="print-area">
                    <div id="budi">
                        <header class="clearfix">
                            <div id="logo">
                                <img src="<?= base_url('assets/img/logo_print.png'); ?>">
                            </div>
                            <h1 id="NL">Laundry Express Bandung 
                                <br>
                                <div id="JL">Jl. Sumber Mekar 9/33, Kompleks Sumbersari Indah – Bandung
                                <br>
                                Telp/Wa. 082118989836
                                <br>
                                Email. Laundry_express@gmail.com
                                </div>
                            </h1>
                            <div id="company">
                                <div><span>NO. ORDER</span>&nbsp; <?= $trans['no_trans'] ; ?></div>
                                <div><span>TANGGAL TRANSAKSI</span>&nbsp; <?= $trans['tgl_transaksi'] ; ?></div>
                                <div><span>TANGGAL AMBIL</span>&nbsp; 
                                <?php if ($trans['tgl_ambil'] === '0000-00-00') { echo "Belum diambil"; } else { echo $trans['tgl_ambil']; }; ?>
                                </div> 
                                
                                <div><span>OPERATOR</span>&nbsp; <?= $trans['operator'] ; ?></div>
                            </div>
                            <div id="project">
                                <div><span>CUSTOMER</span>&nbsp; <?= $pelanggan2['nama'] ; ?></div>
                                <div><span>ALAMAT</span>&nbsp; <?= $pelanggan2['alamat'] ; ?></div>
                                <div><span>TELEPON</span>&nbsp; <?= $pelanggan2['tlp'] ; ?></div>
                            </div>
                        </header>
                        <main>
                            <table>
                                <thead>
                                <tr>
                                    <th class="service">NO.</th>
                                    <th class="desc">PAKET LAUNDRY</th>
                                    <th class="unit">HARGA</th>
                                    <th class="qty">BERAT (Kg)</th>
                                    <th clas="total">TOTAL</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td class="service">1</td>
                                    <td class="desc"><?= $paket2['nama_paket'] ; ?></td>
                                    <td class="unit">Rp. <?= number_format($paket2['harga'],0,",",".") ; ?></td>
                                    <td class="qty"><?= $trans['jml_kilo'] ; ?></td>
                                    <td class="total">Rp. <?= number_format($trans['totalpure'],0,",",".") ; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="4">BIAYA TAMBAHAN</td>
                                    <td class="total">Rp. <?= number_format($trans['biaya_tambahan'],0,",",".") ; ?></td>
                                </tr>
                                <tr>
                                    <td colspan="4">DISKON</td>
                                    <td class="total"><?php echo $trans['diskon']; ?>%</td>
                                </tr>
                                <tr>
                                    <td colspan="4" class="grand total">GRAND TOTAL</td>
                                    <td class="grand total">Rp. <?= number_format($trans['grand_total'],0,",",".") ; ?></td>
                                </tr>    
                                </tbody>
                            </table>

                            <table class="table table-striped" style="margin-top:10px;">
                                <tbody>
                                    <tr>
                                        <td style="text-align:left;">Tunai : Rp. <?= number_format($trans['bayar'],0,",",".") ; ?></td>
                                        <td style="text-align:right;">Kembalian: Rp. <?= number_format($trans['kembalian'],0,",",".") ; ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            <br>
                            <br>
                            <br>

                            <div id="notices">
                                <div>Syarat & Ketentuan :</div>
                                <div class="notice">1. Pengambilan cucian harus membawa nota</div>
                                <div class="notice">2. Cucian luntur bukan tanggung jawab kami</div>
                                <div class="notice">3. Hitung dan periksa sebelum pergi</div>
                                <div class="notice">4. Klaim kekurangan/kehilangan cucian setelah meninggalkan laundry tidak dilayani</div>
                                <div class="notice">5. Cucian yang sudah rusak/mengkerut karena sifat kain tidak dapat kami ganti</div>
                                <div class="notice">6. Cucian yang tidak diambil lebih dari 1 bulan bukan tangggung jawab kami</div>
                                <div class="notice">7. Maksimal penggantian 10x dari total invoice dan barang menjadi milik kami</div>
                            </div>
                            <br>
                        </main>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="printDiv('print-area')" type="button" class="btn btn-primary btn-sm"> Cetak</button>
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal"> Batal</button>
            </div>
            </div>
        </div>
    </div>
<!-- end modal -->