<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><?= $judul; ?></h1>

            
            <!-- form -->
            <div class="card card-shadow mb-4">
                <?= form_open("C_transaksi/addK");?>
                <div id="print-area" class="card-body">
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Kode Pemesanan</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="no_trans" id="form-control" value="<?= $no ; ?>" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Operator</label>
                                <input type="text" class="form-control" name="operator" id="form-control" value="<?= $this->session->userdata('nama'); ?>" readonly>
                            </div>
                            <div class="col-sm-6">
                                <label>Pelanggan</label>
                                <select class="form-control" name="id_member" id="form-control">
                                    <optiom value=""></optiom>
                                    <?php foreach ($pelanggan as $plg) { ?>
                                    <option value="<?= $plg['id_member']; ?>"><?= $plg['nama']; ?></option>
                                    <?php } ; ?>
                                </select>
                                <?= form_error('id_member', '<small class="text-danger">', '</small>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Tanggal Transaksi</label>
                                <input type="date" class="form-control" name="tgl_transaksi" id="hariini" readonly>
                            </div>
                            <div class="col-sm-6">
                                <label>Status</label>
                                <input type="text" value="proses" class="form-control" name="status" id="form-control" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Pilih Paket</label>
                                <select class="form-control" name="id_paket" id="id_paket">
                                    <?php foreach ($paket as $pkt) { ?>
                                        <option value="<?= $pkt['id_paket']; ?>"><?= $pkt['nama_paket']; ?> ( Rp. <?= number_format($pkt['harga'],0,",",".") ; ?> )</option>
                                    <?php } ; ?>
                                </select>
                                <?= form_error('id_paket', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Total Berat (kg)</label>
                                <input type="number" class="form-control" id="jml_kilo" onkeyup="kilo()" name="jml_kilo">  <!-- onkeyup="kilo()" function javascript -->
                                <?= form_error('jml_kilo', '<small class="text-danger">', '</small>'); ?>
                            </div>
                        </div>
                    </div>
                    <!-- name="" for send db -->
                    <!-- id="" for css/javascript -->
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Total</label>
                                <input type="number" class="form-control" id="total" name="totalpure" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Biaya Tambahan</label>
                                <input type="number" class="form-control" name="biaya_tambahan" onkeyup="calculate()" value="0" id="biaya_tambahan">
                                <?= form_error('biaya_tambahan', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Diskon(%)</label>
                                <input type="number" class="form-control" name="diskon" id="diskon" onkeyup="calculate()">
                                <?= form_error('diskon', '<small class="text-danger">', '</small>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Grand Total</label>
                                <input type="number" class="form-control" name="grand_total" id="grand_total" readonly>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group row mb-3">
                            <div class="col-sm-6 mb-5 mb-sm-0">
                                <label>Bayar</label>
                                <input type="number" class="form-control" name="bayar" value="0" id="bayar" onkeyup="calculate()">
                                <?= form_error('bayar', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="col-sm-6">
                                <label>Kembalian</label>
                                <input type="number" class="form-control" name="kembalian" id="kembalian" readonly>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="card-footer">
                    <a class="btn btn-primary btn-sm" href="<?= base_url('C_transaksi/kasir'); ?>"><i class="fas fa-arrow-left"></i>&nbsp; Kembali</a>
                    <button type="reset" class="btn btn-danger btn-sm" value="Reset"><i class="fas fa-sync-alt"></i>&nbsp; Reset</button>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-plus"></i>&nbsp; Tambah</button>
                    <!-- <button onclick="printDiv('print-area')" type="button" class="btn btn-warning btn-sm"><i class="fas fa-print"></i>&nbsp; Cetak</button> -->
                </div>
                <?= form_close(); ?>
            </div>
            
        </div>
    </div>
</div>
<!-- content -->

