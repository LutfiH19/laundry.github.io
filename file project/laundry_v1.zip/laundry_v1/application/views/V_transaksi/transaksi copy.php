<!-- content -->
<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
        <h1 class="h4 mb-4 text-gray-800"><i class="fas fa-shopping-cart"></i>&nbsp; <?= $judul; ?></h1>

        <div class="row">
            <!-- tab 1 -->
            <div class="col-xl-6 col-md-8 mb-4">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="table-responsive">
                <form action="<?php echo base_url()?>shopping/ubah_cart" method="post" name="frmShopping" id="frmShopping" class="form-horizontal" enctype="multipart/form-data">
                    <table class="table">
                        <colgroup>
                        <col width="2%">
                        <col width="10%">
                        <col width="5%">
                        <col width="15%">
                        <col width="2%">
                        <col width="15%">
                        <col width="2%">
                        </colgroup>
                        <tr>
                            <td>No</td>
                            <td>Nama Paket</td>
                            <td>Jenis</td>
                            <td>Harga</td>
                            <td>Total Berat</td>
                            <td>Jumlah</td>
                            <td>Hapus</td>
                        </tr>
                    <?php 
                    // Create form and send all values in "shopping/update_cart" function.
                    foreach ($this->cart->contents() as $item) {
                            $no = 1;
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td><?= $item['nama_paket']; ?></td>
                        <td><?= number_format($item['harga'], 0,",","."); ?></td>
                        <td><input type="number" min="0" max="50" size="5" name="cart[<?= $item['id_paket'];?>][total_berat]" value="<?= $item['total_berat'];?>" /></td>
                        <td><?= number_format($item['subtotal'], 0,",",".") ?></td>
                        <td><a href="<?= base_url()?>C_transaksi/hapus/<?= $item['rowid'];?>" class="btn btn-sm btn-danger"><i class="fas fa-trash-alt"></i></a></td>
                    </tr>
                    <?php } ?>

                </table>
                    <h6 class="text-center"><b>Order Total: Rp <?= number_format($item['harga'], 0,",","."); ?></b></h6>
                    <br>
                    <div class="text-center">
                        <a data-toggle="modal" data-target="#myModal" class='btn btn-sm btn-danger'>Kosongkan Cart</a>
                        <button class='btn btn-sm btn-success' type="submit">Update Cart</button>
                        <a href="<?= base_url()?>shopping/check_out" class ='btn btn-sm btn-primary'>Check Out</a>
                    </div>
                </form>
                </div>
                </div>

                </div>
            </div>

            <!-- tab 2 -->
            <div class="col-xl-6 col-md-6 mb-4">
                <div class="card shadow">
                    <div class="card-header py-3">
                        <h4>List Paket</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered" id="dataTable">
                                <thead>
                                    <tr>
                                        <th style="width: 2%;">No</th>
                                        <th>Nama</th>
                                        <th style="width: 15%;text-align:center;">Jenis</th>
                                        <th style="width: 15%;text-align:center;">Harga</th>
                                        <th style="width: 20%;text-align:center;">Aksi</th>
                                    </tr>
                                </thead>
                                    <tbody>
                                        <?php 
                                        $no = 1;
                                        foreach ($paket as $pkt) { 
                                        ?>
                                            <tr>
                                                <td style="text-align:center;"><?= $no++ ?></td>
                                                <td><?= $pkt->nama_paket; ?></td>
                                                <td style="text-align:center;"><?= $pkt->jenis_paket; ?></td>
                                                <td style="text-align:center;">Rp. <?= number_format($pkt->harga,0,",",".") ; ?></td>
                                                <td style="text-align:center;">
                                                <?= form_open("C_transaksi/tambah_paket"); ?>
                                                    <input type="hidden" name="id_paket" value="<?= $pkt->id_paket; ?>" />
                                                    <input type="hidden" name="nama_paket" value="<?= $pkt->nama_paket; ?>" />
                                                    <input type="hidden" name="jenis_paket" value="<?= $pkt->jenis_paket; ?>" />
                                                    <input type="hidden" name="harga" value="<?= $pkt->harga; ?>" />
                                                    <input type="hidden" name="total_berat" value="1" />
                                                    <button type="submit" class="btn btn-outline-success btn-sm">Tambah</button>                                        
                                                <?= form_close(); ?>
                                                </td>
                                            </tr>
                                        <?php } ; ?> 
                                        </tbody>
                                    </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- end row -->
        </div>

            
        <!-- </div> -->

        </div>
    </div>
</div>
<!-- content -->


            <!-- detail -->
            <!-- <div class="card shadow mb-4">
                <div class="card-header-lg py-3">
                    <h5>Detail</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">

                        <table class="table table-striped table-bordered" id="" width="100%" cellspacing="0">
                            <colgroup>
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th>Jenis</th>
                                    <th>Berat</th>
                                    <th>Biaya Tambahan</th>
                                    <th>Diskon</th>
                                    <th>Bayar</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div> -->

            <!-- <div class="card shadow mb-4 border-primary">
                <div class="card-header-lg py-3 ">
                    <a href="<?= base_url('C_transaksi/add') ?>" class="btn btn-success btn-sm btn-round ml-auto"><i class="fas fa-plus"></i>&nbsp; Buat Transaksi</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <colgroup>
                                <col width="2%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="5%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="text-center">No</th>
                                    <th>Kode Pemesanan</th>
                                    <th>Pelanggan</th>
                                    <th>Operator</th>
                                    <th>Tanggal Transaksi</th>
                                    <th>Tanggal Ambil</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                    <tr>
                                        <th class="text-center" scope="row"><?= $no; ?></th>
                                        <td>LDY00001</td>
                                        <td>udin</td>
                                        <td>Kasir merah</td>
                                        <td>27 jan 2021</td>
                                        <td>31 jan 2021</td>
                                        <td>selesai</td>
                                        <td class="text-center">
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-bs-toggle="dropdown">
                                                Aksi
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="#">Perbarui</a></li>
                                                <li><hr class="dropdown-divider"></hr></li>
                                                <li><a class="dropdown-item" href="#">Hapus</a></li>
                                                <li><hr class="dropdown-divider"></hr></li>
                                                <li><a class="dropdown-item" href="#">Cetak</a></li>
                                            </ul>
                                        </div>
                                        </td>
                                    </tr>
                                <?php $no++; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> -->
