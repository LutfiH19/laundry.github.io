<!-- content -->
<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
        <h1 class="h4 mb-4 text-gray-800"><i class="fas fa-shopping-cart"></i>&nbsp; <?= $judul; ?></h1>
        <?= $this->session->flashdata('pesan_transaksi'); ?>
            <div class="card shadow mb-4 border-primary">
                <div class="card-header-lg py-3 ">
                    <a href="<?= base_url('C_transaksi/addK') ?>" class="btn btn-success btn-sm btn-round ml-auto"><i class="fas fa-plus"></i>&nbsp; Buat Transaksi</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <colgroup>
                                <col width="2%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="10%">
                                <col width="5%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Kode Pemesanan</th>
                                    <th>Pelanggan</th>
                                    <th class="text-center">Tanggal Transaksi</th>
                                    <th class="text-center">Tanggal Ambil</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                foreach ($transaksiK as $tr2) { 
                                ?>
                                    <tr>
                                        <th class="text-center" scope="row"><?= $no++ ?></th>
                                        <td class="text-center"><?= $tr2->no_trans; ?></td>
                                        <td class="text-center"><?= $tr2->nama; ?></td>
                                        <td class="text-center"><?= $tr2->tgl_transaksi; ?></td>
                                        <td class="text-center">
                                        <?php if ($tr2->tgl_ambil === '0000-00-00') { echo "Belum diambil"; } else { echo $tr2->tgl_ambil; }; ?>
                                        </td>
                                        <td class="text-center">
                                        <?php
                                        if ($tr2->status == 'proses') 
                                        {
                                            echo "<button type='button' class='btn btn-sm btn-secondary rounded-3'><i class='fas fa-sync'></i> Proses</button>";
                                        }
                                        elseif ($tr2->status == 'selesai') 
                                        {
                                            echo "<button type='button' class='btn btn-sm btn-warning rounded'><i class='fas fa-check'></i> Selesai</button>";
                                        } 
                                        elseif ($tr2->status == 'diambil') 
                                        {
                                            echo "<button type='button' class='btn btn-sm btn-success rounded'><i class='fas fa-check-double'></i> Diambil</button>";
                                        }
                                        ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?= base_url('C_transaksi/ubahK/'. $tr2->id_transaksi) ?>" type="button" data-original-title="Detail" class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                    <?php } ; ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- content -->