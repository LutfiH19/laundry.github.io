<!-- content -->
<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
        <h1 class="h4 mb-4 text-gray-800"><i class="fas fa-shopping-cart"></i>&nbsp; <?= $judul; ?></h1>
        <?= $this->session->flashdata('pesan_transaksi'); ?>
            <div class="card shadow mb-4 border-primary">
                <div class="card-header-lg py-3 ">
                    <a href="<?= base_url('C_transaksi/add') ?>" class="btn btn-success btn-sm btn-round ml-auto"><i class="fas fa-plus"></i>&nbsp; Buat Transaksi</a>
                </div> 
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <!-- <colgroup>
                                <col width="2%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="15%">
                                <col width="10%">
                                <col width="5%">
                            </colgroup> -->
                            <thead>
                                <tr>
                                    <th class="text-center" width="2%">No</th>
                                    <th class="text-center" width="15%">Kode Pemesanan</th>
                                    <th>Pelanggan</th>
                                    <th class="text-center" width="15%">Tanggal Transaksi</th>
                                    <th class="text-center" width="15%">Tanggal Ambil</th>
                                    <th class="text-center" width="10%">Status</th>
                                    <th class="text-center" width="5%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                foreach ($transaksi as $tr) { 
                                ?>
                                    <tr>
                                        <th class="text-center" width="2%"><?= $no++ ?></th>
                                        <td class="text-center" width="15%"><?= $tr->no_trans; ?></td>
                                        <td class="text-center" width="15%"><?= $tr->nama; ?></td>
                                        <td class="text-center" width="15%"><?= $tr->tgl_transaksi; ?></td>
                                        <td class="text-center" width="15%">
                                        <?php if ($tr->tgl_ambil === '0000-00-00') { echo "Belum diambil"; } else { echo $tr->tgl_ambil; }; ?>
                                        </td>
                                        <td class="text-center" width="10%">
                                        <?php
                                        if ($tr->status == 'proses') 
                                        {
                                            echo "<button type='button' class='btn btn-sm btn-secondary rounded-3'><i class='fas fa-sync'></i> Proses</button>";
                                        }
                                        elseif ($tr->status == 'selesai') 
                                        {
                                            echo "<button type='button' class='btn btn-sm btn-warning rounded'><i class='fas fa-check'></i> Selesai</button>";
                                        } 
                                        elseif ($tr->status == 'diambil') 
                                        {
                                            echo "<button type='button' class='btn btn-sm btn-success rounded'><i class='fas fa-check-double'></i> Diambil</button>";
                                        }
                                        ?>
                                        </td>
                                        <td class="text-center" width="5%">
                                            <a href="<?= base_url('C_transaksi/ubah/'. $tr->id_transaksi) ?>" type="button" data-original-title="Detail" class="btn btn-sm btn-primary">
                                                <i class="fas fa-eye"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                    <?php } ; ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        <!-- </div> -->

        </div>
    </div>
</div>
<!-- content -->


