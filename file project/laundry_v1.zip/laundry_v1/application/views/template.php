<!DOCTYPE html>
<html lang="en">
    <meta charset="utf-8">
<head>
	<title><?= $judul; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="shortcut icon" href="<?= base_url('assets/img/washing-machine (3).png'); ?>">
	<!-- bootstrap 5 css -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
	<!-- print css -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/print.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/card.css'); ?>">
	<!-- dataTables -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/datatables/css/dataTables.bootstrap5.css'); ?>">
	<!-- font awesome -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/vendor/fontawesome-free/css/all.min.css'); ?>">
	<!-- Icomoon Font Icons css -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/fonts/style.css'); ?>">
	<!-- Main css -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/main.css'); ?>">
	<!-- Search Filter JS -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/vendor/search-filter/search-filter.css'); ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/vendor/search-filter/custom-search-filter.css'); ?>">
</head>
	<body class="default-sidebar">
		<!-- Loading wrapper -->
		<!-- <div id="loading-wrapper">
			<div class="spinner-border"></div>
		</div> -->

		<!-- Page wrapper start -->
		<div class="page-wrapper">
			<!-- sidebar -->
			<nav class="sidebar-wrapper">
				<div class="default-sidebar-wrapper">
					<!-- Sidebar brand -->
					<div class="default-sidebar-brand">
						<a href="" class="logo">
							<img src="<?= base_url('assets/img/washing-machine (4).png');?>" title="Laundry Express Bandung">
							<h3 class="ms-3 mt-2 mb-3" style="color: #52527a;">
								<?= $this->session->userdata('role'); ?>
							</h4>
						</a>
					</div>
					<!-- Sidebar brand -->

					<!-- Sidebar menu -->
                    <!-- defaultSidebarMenuScroll -->
					<div class="defaultSidebarMenuScroll">
						<div class="default-sidebar-menu">
							<ul>
								<!-- Admin -->
							    <?php if($this->session->userdata('role')==='Admin'):?>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_beranda' ? 'active' : null?>">
									<!-- segment (1) -> controller -->
									<!-- segment (2) -> method/function -->
										<a href="<?= base_url('C_beranda') ;?>">
											<i class="fas fa-home"></i>
											<span class="menu-text">Beranda</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_outlet' ? 'active' : null?>">
										<a href="<?= base_url('C_outlet') ;?> ">
											<i class="fas fa-shopping-basket"></i>
											<span class="menu-text">Outlet</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_paket' ? 'active' : null?>">
										<a href="<?= base_url('C_paket') ;?>">
											<i class="fas fa-box"></i>
											<span class="menu-text">Paket</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_pelanggan' ? 'active' : null?>">
										<a href="<?= base_url('C_pelanggan') ;?>">
											<i class="fas fa-users"></i>
											<span class="menu-text">Pelanggan</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_transaksi' ? 'active' : null?>">
										<a href="<?= base_url('C_transaksi') ;?>">
											<i class="fas fa-hand-holding-usd"></i>
											<span class="menu-text">Transaksi</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_user' ? 'active' : null?>">
										<a href="<?= base_url('C_user') ;?>">
											<i class="fas fa-user-cog"></i>
											<span class="menu-text">Pengguna</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_laporan' ? 'active' : null?>">
										<a href="<?= base_url('C_laporan') ;?>">
											<i class="fas fa-print"></i>
											<span class="menu-text">Laporan</span>
										</a>
									</li>

									<!-- kasir -->
                                <?php elseif($this->session->userdata('role')==='Kasir'):?>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_pelanggan' ? 'active' : null?>">
										<a href="<?= base_url('C_pelanggan/kasir') ;?>">
											<i class="fas fa-users"></i>
											<span class="menu-text">Pelanggan</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_transaksi' ? 'active' : null?>">
										<a href="<?= base_url('C_transaksi/kasir') ;?>">
											<i class="fas fa-shopping-cart"></i>
											<span class="menu-text">Transaksi</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_laporan' ? 'active' : null?>">
										<a href="<?= base_url('C_laporan/kasir') ;?>">
											<i class="fas fa-print"></i>
											<span class="menu-text">Laporan</span>
										</a>
									</li>

									<!-- owner -->
								<?php else: ?>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_beranda' ? 'active' : null?>">
										<a href="<?= base_url('C_beranda/owner') ;?>">
											<i class="fas fa-home"></i>
											<span class="menu-text">Beranda</span>
										</a>
									</li>
									<li class="default-sidebar <?=$this->uri->segment(1) == 'C_laporan' ? 'active' : null?>">
										<a href="<?= base_url('C_laporan/owner') ;?>">
											<i class="fas fa-print"></i>
											<span class="menu-text">Laporan</span>
										</a>
									</li>

								<?php endif;?>
									<br>
									<br>
									<li class="default-sidebar">
										<a href="" data-bs-toggle="modal" data-bs-target="#logout">
											<i class="fas fa-sign-out-alt"></i>
											<span class="menu-text">Keluar</span>
										</a>
									</li>
							</ul>
						</div>
					</div>
					<!-- sidebar menu -->
				</div>
			</nav>
			<!-- sidebar -->

			<div class="main-container">

				<!-- Navbar -->
				<div class="page-header">
					<div class="row gutters">
						<div class="col-xl-8 col-lg-8 col-md-8 col-sm-6 col-9">
							<!-- Search -->
							<div class="search-container">
								<div class="toggle-sidebar" id="toggle-sidebar">
									<i class="icon-menu"></i>
								</div>
								<!-- <div class="ui fluid category search">
									<div class="ui icon input">
										<input type="text" class="prompt" placeholder="Cari">
										<i type="submit" name="" class="search icon icon-search"></i>
									</div>
									<div class="results"></div>
								</div> -->
							</div>
							<!-- Search -->
						</div>

						<!-- menu -->
						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-3">
							<ul class="header-actions">
								<!-- menu -->
								<li>
									<span class="mr-5 d-none d-lg-inline text-gray-600 small"><?= $this->session->userdata('nama'); ?></span>
								</li>
								<li class="dropdown">
									<a id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
										<span class="avatar">											
											<img src="<?= base_url('assets/img/man.png');?>" alt="User Avatar">
										</span>
									</a>
									<div class="dropdown-menu dropdown-menu-end md" aria-labelledby="userSettings">
										<div class="header-profile-actions">
											<!-- <a href="user-profile.html"><i class="icon-user1"></i>Profile</a>
											<a href="#" ><i class="icon-settings1"></i>Settings</a> -->
											<a href="" data-bs-toggle="modal" data-bs-target="#logout"><i class="icon-log-out1"></i>Logout</a>
										</div>
									</div>
								</li>
							</ul>
						</div>
						<!-- menu -->
					</div>
			    </div>
			    <!-- Navbar -->

					<!-- Content wrapper scroll start -->
					<div class="content-wrapper-scroll">
						<?= $konten; ?>
						<div class="app-footer"><h6>© Laundry Express Bandung 2022</h6></div> <!-- App Footer -->
				    </div>
					<!-- Content wrapper scroll end -->

					<!-- modal logout -->
					<?= form_open("C_login/keluar"); ?>
					<div class="modal fade" id="logout" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
						<div class="modal-dialog">
							<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-sign-out-alt"></i>&nbsp;  Keluar dari semua sesi</h5>
							</div>
							<div class="modal-body">
								<h4>Hapus semua sesi yang ada saat ini ?</h4>
							</div>
							<div class="modal-footer">
								<button type="submit" class="btn btn-danger btn-sm">Keluar</button>
								<button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
							</div>
							</div>
						</div>
					</div>
					<?= form_close(); ?>
					<!-- end modal -->

			</div>
		</div>
		<!-- Page wrapper end -->

        <!-- script -->
            <!-- Required jQuery first, then Bootstrap Bundle JS -->
            <script type="text/javascript" src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
            <!-- datatables -->
            <script type="text/javascript" src="<?= base_url('assets/bootstrap/js/bootstrap.bundle.js'); ?>"></script>
            <script type="text/javascript" src="<?= base_url('assets/datatables/js/jquery.dataTables.js'); ?>"></script>
            <script type="text/javascript" src="<?= base_url('assets/datatables/js/dataTables.bootstrap5.js'); ?>"></script>
            <!-- <script type="text/javascript" src="<?= base_url('assets/js/jquery-3.6.0.js'); ?>"></script> -->
			
			<script type="text/javascript" src="<?= base_url('assets/js/modernizr.js'); ?>"></script>
            <script type="text/javascript" src="<?= base_url('assets/js/moment.js'); ?>"></script>
            <!-- Slimscroll JS -->
            <script type="text/javascript" src="<?= base_url('assets/vendor/slimscroll/slimscroll.min.js'); ?>"></script>
            <script type="text/javascript" src="<?= base_url('assets/vendor/slimscroll/custom-scrollbar.js'); ?>"></script>
            <!-- Search Filter JS -->
            <script type="text/javascript" src="<?= base_url('assets/vendor/search-filter/search-filter.js'); ?>"></script>
            <script type="text/javascript" src="<?= base_url('assets/vendor/search-filter/custom-search-filter.js'); ?>"></script>
            <!-- Main Js Required -->
            <script type="text/javascript" src="<?= base_url('assets/js/main.js'); ?>"></script>
        <!-- script -->

		<!-- dataTable -->
			<script type="text/javascript">
				$(document).ready(function() {
					$('#dataTable').DataTable({
						responsive: true,
						"aLengthMenu": [[5, 10, 25, 50, 75, 100, -1], [5, 10, 25, 50, 75, 100, "All"]],
						"pageLength": 5});
				} );
			</script>
		<!-- alert bootstrap -->
			<script type="text/javascript">
			$(document).ready(function () {
			window.setTimeout(function() {
				$(".alert").fadeTo(1000, 0).slideUp(1000, function(){
					$(this).remove(); 
				});
			}, 5000);
			});
			</script>

		<!-- disable right click -->
			<!-- <script type="text/javascript">
				window.oncontextmenu = function () 
				{
					return false;
				}
				$(document).keydown(function (event){
					if (event.keyCode == 123) 
					{
						return false;
					}
					else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) 
					{
						return false;
					}
				});
			</script> -->
		<!-- auto insert datetime -->
			<script type="text/javascript">
				// var now = new Date();
				// now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
				// document.getElementById('hariini').value = now.toISOString().slice(0,16);
				var date = new Date();
				var day = date.getDate();
				var month = date.getMonth() + 1;
				var year = date.getFullYear();
				if (month < 10) month = "0" + month;
				if (day < 10) day = "0" + day;
				var today = year + "-" + month + "-" + day;
				document.getElementById('hariini').value = today;
			</script>

        <!-- mix -->
			<script type="text/javascript">

				function printDiv(divName) // print
				{
					let printContents = document.getElementById(divName).innerHTML;
					let originalContents = document.body.innerHTML;
					document.body.innerHTML = printContents;
					window.print();
					document.body.innerHTML = originalContents;
					location.reload(true);
					setTimeout(function() {}, 50); // 50 milisecond
				}
				
				function calculate() // calculate
				{ 
					var total = parseInt(document.getElementById("total").value); // total
					var biaya_tambahan = parseInt(document.getElementById("biaya_tambahan").value) // biaya tambahan
					var diskon = parseInt(document.getElementById("diskon").value) // diskon
					var bayar = parseInt(document.getElementById("bayar").value) // bayar
					var grand_total = parseInt(document.getElementById("grand_total").value) // total

					document.getElementById("kembalian").value = (bayar) - ((total + biaya_tambahan) - (total + biaya_tambahan) * (diskon / 100)) , // bayar - total = kembalian
					document.getElementById("grand_total").value = (total + biaya_tambahan) - (total + biaya_tambahan) * (diskon / 100); // total
				}

				function kilo() // kilo
				{
					paket = $("#id_paket").val();
					jml_kilo = $("#jml_kilo").val();
					if (paket == "")
					{
						alert("Pilih Paket Terlebih Dahulu");
					}
					else
					{
						$.ajax
						({
							url  : "<?= site_url('C_transaksi/kilo') ?>",
							type : "POST",
							data : { 
									paket : paket,
									jml_kilo : jml_kilo

								},
							success:function (data)
							{
								$("#total").val(data);
							}
						})
					}
				}

			</script>
	</body>
</html>
