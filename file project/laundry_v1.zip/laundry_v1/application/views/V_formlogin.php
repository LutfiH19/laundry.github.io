<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?= $judul; ?></title>
	<!-- fontawesome -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/vendor/fontawesome-free/css/all.min.css'); ?>">
	<!-- bootstrap -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css'); ?>">
	<!-- main css -->
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/form.css'); ?>">
	<!-- fav icon -->
	<link rel="shortcut icon" href="<?= base_url('assets/img/washing-machine (3).png'); ?>">
</head>
<body id="body">

	<div class="wrapper">
		<div class="login">
			<h2 class="text-center">Selamat Datang</h2>
			<br>
			<?= $this->session->flashdata('message'); ?>
			<?= form_open('C_login/masuk'); ?>
			<div class="input-group mb-1 mt-3">
				<input type="text" class="form-control" id="username"  name="username" placeholder="Username" value="<?= set_value('username'); ?>">
				<div class="input-group-append">
					<div class="input-group-text">
						<span class="fas fa-user-circle"></span>
					</div>
				</div>
			</div>
			<div class="fe">
				<?= form_error('username', '<small class="text-danger pl-3">', '</small>'); ?>
			</div>
				<br>
			<div class="input-group mb-1">
				<input type="password" class="form-control" id="password"  name="password" placeholder="Password">
				<div class="input-group-append">
					<div class="input-group-text">
						<span class="fas fa-lock"></span>
					</div>
				</div>
			</div>
			<div class="fe">
				<?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
			</div>
				<br>
			<button type="submit" name="submit" class="btn btn-primary deep-purple btn-block ">Masuk</button>
			<?= form_close(); ?>
		</div>
	</div>

	<!--  -->
		<script type="text/javascript" src="<?= base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"> </script>
		<script type="text/javascript" src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>

	<!-- alert bootstrap -->
		<script type="text/javascript">
		$(document).ready(function () {
		window.setTimeout(function() {
			$(".alert").fadeTo(1000, 0).slideUp(1000, function(){
				$(this).remove(); 
			});
		}, 5000);
		});
		</script>
	
</body>
</html>