<!-- Content ! -->
<div class="content-wrapper">
	<div class="row gutters">
		<div class="col-lg-12">
			<h1 class="h3 mb-4 text-gray-800"><i class="fas fa-home"></i>&nbsp;  <?= $judul; ?></h1>
		<!-- 4 card -->
		<div class="row">
            <div class="col-xl-3 col-lg-6">
              <div class="card shadow card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-2">OUTLET</h5>
                      <span class="h4 font-weight-bold"><?= $jumlah_outlet?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                        <i class="fas fa-shopping-basket"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card shadow card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-2">PELANGGAN</h5>
                      <span class="h4 font-weight-bold mt-3"><?= $jumlah_pelanggan?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                        <i class="fas fa-users"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card shadow card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-2">TRANSAKSI</h5>
                      <span class="h4 font-weight-bold mt-3"><?= $jumlah_transaksi?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-yellow text-white rounded-circle shadow">
                        <i class="fas fa-dollar-sign"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6">
              <div class="card shadow card-stats mb-4 mb-xl-0">
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-2">PENGHASILAN</h5>
                      <span class="h4 font-weight-bold mt-3">Rp. <?= number_format($total_penghasilan,0,",",".") ; ?></span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                        <i class="fas fa-chart-line"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
		</div>

		<!-- table -->
		<div class="card shadow mt-4">
				<div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <!-- <colgroup>
                        <col width="2%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="15%">
                        <col width="10%">
                        <col width="5%">
                    </colgroup> -->
                    <thead>
                        <tr>
                            <th class="text-center" width="2%">No</th>
                            <th class="text-center" width="15%">Kode Pemesanan</th>
                            <th class="text-center" width="15%">Pelanggan</th>
                            <th class="text-center" width="15%">Tanggal Transaksi</th>
                            <th class="text-center" width="15%">Tanggal Ambil</th>
                            <th class="text-center" width="10%">Status</th>
                        <?php if($this->session->userdata('role') !='Owner'):?>
                            <th class="text-center" width="5%">Aksi</th>
                        <?php endif;?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        foreach ($transaksi as $tr) { 
                        ?>
                            <tr>
                                <th class="text-center" width="2%"><?= $no++ ?></th>
                                <td class="text-center" width="15%"><?= $tr->no_trans; ?></td>
                                <td class="text-center" width="15%"><?= $tr->nama; ?></td>
                                <td class="text-center" width="15%"><?= $tr->tgl_transaksi; ?></td>
                                <td class="text-center" width="15%">
                                <?php if ($tr->tgl_ambil === '0000-00-00') { echo "Belum diambil"; } else { echo $tr->tgl_ambil; }; ?>
                                </td>
                                <td class="text-center" width="10%">
                                <?php
                                if ($tr->status == 'proses') 
                                {
                                    echo "<button type='button' class='btn btn-sm btn-secondary rounded-3'><i class='fas fa-sync'></i> Proses</button>";
                                }
                                elseif ($tr->status == 'selesai') 
                                {
                                    echo "<button type='button' class='btn btn-sm btn-warning rounded'><i class='fas fa-check'></i> Selesai</button>";
                                } 
                                elseif ($tr->status == 'diambil') 
                                {
                                    echo "<button type='button' class='btn btn-sm btn-success rounded'><i class='fas fa-check-double'></i> Diambil</button>";
                                }
                                ?>
                                </td>
                          <?php if($this->session->userdata('role') !='Owner'):?>
                                <td class="text-center" width="5%">
                                  <?php if($this->session->userdata('role') ==='Admin'):?>
                                    <a href="<?= base_url('C_transaksi/ubah/'. $tr->id_transaksi) ?>" type="button" data-original-title="Detail" class="btn btn-sm btn-primary">
                                  <?php endif;?>
                                    <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                          <?php endif;?>
                            </tr>
                            <?php } ; ?> 
                    </tbody>
                </table>
            </div>
        </div>
		</div>



		</div>
	</div>
</div>
<!-- Content ! -->