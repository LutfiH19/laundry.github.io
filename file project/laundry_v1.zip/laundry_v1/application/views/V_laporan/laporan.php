<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
        <h1 class="h3 mb-4 text-gray-800"><i class="fas fa-print"></i>&nbsp;  <?= $judul; ?></h1>

            <div class="card shadow mt-4">
                <div class="card-header-lg py-3 ">
                    <a href="" data-bs-toggle="modal" data-bs-target="#cetak" class="btn btn-warning btn-sm btn-round ml-auto"><i class="fas fa-print"></i>&nbsp; Cetak</a>
                </div> 
				<div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th class="text-center" width="2%">No</th>
                                    <th class="text-center">Kode Pemesanan</th>
                                    <th class="text-center">Pelanggan</th>
                                    <th class="text-center">Tanggal Transaksi</th>
                                    <th class="text-center">Operator</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                foreach ($transaksi as $tr) { 
                                ?>
                                    <tr>
                                        <th class="text-center" width="2%"><?= $no++ ?></th>
                                        <td class="text-center" width="15%"><?= $tr->no_trans; ?></td>
                                        <td class="text-center" width="15%"><?= $tr->nama; ?></td>
                                        <td class="text-center" width="15%"><?= $tr->tgl_transaksi; ?></td>
                                        <td class="text-center" width="15%"><?= $tr->operator; ?></td>
                                        <td class="text-center" width="10%"><?= $tr->status; ?></td>
                                        <td class="text-center" width="5%">Rp. <?= number_format($tr->grand_total,0,",",".") ; ?></td>
                                    </tr>
                                    <?php } ; ?> 
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal print -->
<div class="modal fade" id="cetak" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-print"></i>&nbsp;  Cetak Data Transaksi !</h5>
            </div>
            <div class="modal-body">
                <div class="table-responsive" id="print-area">
                    <div class="text-center">
                        <h2>DATA LAPORAN TRANSAKSI LAUNDRY</h2>
                        <h6><?= strftime('%A %d %B %Y / %R') ?></h6>
                        <h6 class="mr-auto">Oleh : <?= $this->session->userdata('username'); ?></h6>
                        <br>
                    </div>
                    <table class="table table-bordered" style="width: 100%;">
                        <thead>
                        <tr>
                            <th class="text-center" width="2%">No</th>
                            <th class="text-center">Kode Pemesanan</th>
                            <th class="text-center">Pelanggan</th>
                            <th class="text-center">Tanggal Transaksi</th>
                            <th class="text-center">Operator</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Total</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($transaksi as $tr) {
                            ?>
                            <tr>
                                <th class="text-center" width="2%"><?= $no++ ?></th>
                                <td class="text-center" width="15%"><?= $tr->no_trans; ?></td>
                                <td class="text-center" width="15%"><?= $tr->nama; ?></td>
                                <td class="text-center" width="15%"><?= $tr->tgl_transaksi; ?></td>
                                <td class="text-center" width="15%"><?= $tr->operator; ?></td>
                                <td class="text-center" width="10%"><?= $tr->status; ?></td>
                                <td class="text-center" width="5%">Rp. <?= number_format($tr->grand_total,0,",",".") ; ?></td>
                            </tr>
                            <?php } ;?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button onclick="printDiv('print-area')" type="button" class="btn btn-primary btn-sm"> Cetak</button>
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal"> Batal</button>
            </div>
            </div>
        </div>
    </div>
<!-- end modal -->