<div class="content-wrapper">
        <div class="row gutters">
            <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><?= $judul; ?></h1>
                <div class="card card-shadow mb-4">
                <?= form_open("C_paket/add");?>
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nama Paket</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="nama_paket" id="form-control">
                            </div>
                            <?= form_error('nama_paket',  '<small class="text-danger">','</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Jenis Paket</label>
                            <div class="input-group">
                                <select class="form-control" name="jenis_paket" id="form-control">
                                    <option value=""></option>
                                    <option value="kiloan">kiloan</option>
                                    <option value="satuan">satuan</option>
                                </select>
                            </div>
                            <?= form_error('jenis_paket', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Harga</label>
                            <div class="input-group">
                                <input type="number" class="form-control" name="harga" id="form-control">
                            </div>
                            <?= form_error('harga', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Pilih Outlet</label>
                            <div class="input-group">
                                <select class="form-control" name="id_outlet" id="form-control">
                                    <option value=""></option>
                                <?php foreach ($outlet as $out) { ?>
                                    <option value="<?= $out->id_outlet; ?>"><?= $out->nama_outlet; ?></option>
                                <?php } ; ?>
                                </select>
                            </div>
                            <?= form_error('id_outlet', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a class="btn btn-primary btn-sm" href="<?= base_url('C_paket'); ?>"><i class="fas fa-arrow-left"></i>&nbsp; Kembali</a>
                    <button type="reset" class="btn btn-danger btn-sm" value="Reset"><i class="fas fa-sync-alt"></i>&nbsp; Reset</button>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-save"></i>&nbsp; Simpan</button>
                </div>
                <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- content -->
