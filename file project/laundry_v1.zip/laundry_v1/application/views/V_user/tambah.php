<div class="content-wrapper">
        <div class="row gutters">
            <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><?= $judul; ?></h1>
                <div class="card card-shadow mb-4">
                <?= form_open("C_user/add");?>
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nama</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="nama" id="form-control">
                            </div>
                            <?= form_error('nama',  '<small class="text-danger">','</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Username</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="username" id="form-control">
                            </div>
                            <?= form_error('username', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="password" id="form-control">
                            </div>
                            <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Role</label>
                            <div class="input-group">
                                <select name="role" class="form-control" id="form-control">
                                    <option value="" selected>--Pilih Role--</option>
                                    <option value="Kasir">Kasir</option>
                                    <option value="Owner">Owner</option>
                                </select>
                            </div>
                            <?= form_error('role', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a class="btn btn-primary btn-sm" href="<?= base_url('C_user'); ?>"><i class="fas fa-arrow-left"></i>&nbsp; Kembali</a>
                    <button type="reset" class="btn btn-danger btn-sm" value="Reset"><i class="fas fa-sync-alt"></i>&nbsp; Reset</button>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-save"></i>&nbsp; Simpan</button>
                </div>
                <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- content -->
