    <!-- content -->
    <div class="content-wrapper">
        <div class="row gutters">
            <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><i class="fas fa-user"></i>&nbsp; <?= $judul; ?></h1>
            <?= $this->session->flashdata('pesan_user'); ?>
                <div class="card shadow mb-4">
                    <div class="card-header-lg py-3">
                        <a href="<?= base_url('C_user/add');?>" class="btn btn-success btn-sm round"><i class="fas fa-plus"></i>&nbsp; Tambah Data</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">

                            <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <colgroup>
                                    <col width="2%">
                                    <col width="15%">
                                    <col width="15%">
                                    <col width="10%">
                                    <col width="5%">
                                </colgroup>
                                <thead>
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th class="text-center">Nama</th>
                                        <th class="text-center">Username</th>
                                        <th class="text-center">Role</th>
                                        <th class="text-center">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1; ?>
                                   <?php foreach ($userv as $su) { ?>
                                        <tr>
                                            <th class="text-center" scope="row"><?= $no++ ?></th>
                                            <td class="text-center"><?= $su->nama; ?></td>
                                            <td class="text-center"><?= $su->username;?></td>
                                            <td class="text-center"><?= $su->role; ?></td>
                                            <td class="text-center">
                                                <div class="dropdown">
                                                    <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-bs-toggle="dropdown">
                                                        Aksi
                                                    </button>
                                                    <ul class="dropdown-menu">
                                                        <li><a class="dropdown-item" href="<?= base_url('C_user/ubah/'. $su->id_user); ?>">Perbarui</a></li>
                                                        <li><hr class="dropdown-divider"></hr></li>
                                                        <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#hapus<?= $su->id_user; ?>">Hapus</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                   <?php } ; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- content -->


<!-- Modal hapus -->
    <?php foreach ($userv as $su) { ?>
    <?= form_open("C_user/drop"); ?>
    <div class="modal fade" id="hapus<?= $su->id_user; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-trash-alt"></i>&nbsp;  Hapus data pengguna !</h5>
        </div>
        <div class="modal-body">
            <h4>Yakin ?</h4>
        </div>
        <input type="hidden" name="hapus" value="<?= $su->id_user; ?>">
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger btn-sm">Oke</button>
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
        </div>
        </div>
    </div>
    </div>
    <?= form_close(); ?>
    <?php } ; ?>
<!-- end modal -->