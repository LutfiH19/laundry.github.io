<!-- content -->
<div class="content-wrapper">
    <div class="row gutters">
        <div class="col-lg-12">
        <h1 class="h4 mb-4 text-gray-800"><i class="fas fa-users"></i>&nbsp; <?= $judul; ?></h1>
        <?= $this->session->flashdata('pesan_pelanggan'); ?>
            <div class="card shadow mb-4">
                <div class="card-header-lg py-3">
                    <a href="<?= base_url('C_pelanggan/add') ?>" class="btn btn-success btn-sm"><i class="fas fa-plus"></i>&nbsp; Tambah Data</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <colgroup>
                                <col width="2%">
                                <col width="15%">
                                <col width="15%">
                                <col width="5%">
                                <col width="5%">
                                <col width="2%">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Nama</th>
                                    <th class="text-center">Alamat</th>
                                    <th class="text-center">Nomor Telepon</th>
                                    <th class="text-center">Jenis Kelamin</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; ?>
                                <?php foreach ($pelanggan as $plg) { ?>
                                    <tr>
                                        <th class="text-center"><?= $no++ ?></th>
                                        <td class="text-center"><?= $plg->nama; ?></td>
                                        <td class="text-center"><?= $plg->alamat; ?></td>
                                        <td class="text-center"><?= $plg->tlp; ?></td>
                                        <td class="text-center"><?= $plg->jenis_kelamin; ?></td>
                                        <td class="text-center">
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-bs-toggle="dropdown">
                                                Aksi
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="<?= base_url('C_pelanggan/ubah/'. $plg->id_member); ?>">Perbarui</a></li>
                                                <li><hr class="dropdown-divider"></hr></li>
                                                <li><a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#hdp<?= $plg->id_member; ?>">Hapus</a></li>
                                            </ul>
                                        </div>
                                        </td>
                                    </tr>
                                <?php } ; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- content -->

<!-- Modal hapus -->
<?php foreach ($pelanggan as $plg) { ?>
    <?= form_open("C_pelanggan/drop"); ?>
    <div class="modal fade" id="hdp<?= $plg->id_member; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="staticBackdropLabel"><i class="fas fa-trash-alt"></i>&nbsp; Hapus data pelanggan !</h5>
        </div>
        <div class="modal-body">
            <h4>Yakin ?</h4>
        </div>
        <input type="hidden" name="hapus" value="<?= $plg->id_member; ?>">
        <div class="modal-footer">
            <button type="submit" class="btn btn-danger btn-sm">Oke</button>
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
        </div>
        </div>
    </div>
    </div>
    <?= form_close(); ?>
    <?php } ; ?>
<!-- end modal -->
