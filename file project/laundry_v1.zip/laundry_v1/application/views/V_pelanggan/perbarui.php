<div class="content-wrapper">
        <div class="row gutters">
            <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><?= $judul; ?></h1>
                <div class="card card-shadow mb-4">
                <?= form_open("C_pelanggan/ubah/".$pelanggan['id_member']);?>
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nama</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="nama" id="form-control" value="<?= $pelanggan['nama']; ?>">
                            </div>
                            <?= form_error('nama',  '<small class="text-danger">','</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Alamat</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="alamat" id="form-control" value="<?= $pelanggan['alamat']; ?>">
                            </div>
                            <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Jenis Kelamin</label>
                            <div class="input-group">
                                <select class="form-control" name="jenis_kelamin" id="form-control">
                                    <option value="<?= $pelanggan['jenis_kelamin']; ?>"><?= $pelanggan['jenis_kelamin']; ?></option>
                                    <option value=""></option>
                                    <option value="Pria">Pria</option>
                                    <option value="Wanita">Wanita</option>
                                </select>
                            </div>
                            <?= form_error('jenis_kelamin', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nomor Telepon</label>
                            <div class="input-group">
                                <input type="number" class="form-control" name="tlp" id="form-control" value="<?= $pelanggan['tlp']; ?>">
                            </div>
                            <?= form_error('tlp', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a class="btn btn-primary btn-sm" href="<?= base_url('C_pelanggan'); ?>"><i class="fas fa-arrow-left"></i>&nbsp; Kembali</a>
                    <button type="reset" class="btn btn-danger btn-sm" value="Reset"><i class="fas fa-sync-alt"></i>&nbsp; Reset</button>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-save"></i>&nbsp; Simpan</button>
                </div>
                <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- content -->
