<div class="content-wrapper">
        <div class="row gutters">
            <div class="col-lg-12">
            <h1 class="h4 mb-4 text-gray-800"><?= $judul; ?></h1>
                <div class="card card-shadow mb-4">
                <?= form_open("C_outlet/ubah/".$outlet['id_outlet']);?>
                <div class="card-body">
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nama</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="nama_outlet" id="form-control" value="<?= $outlet['nama_outlet']; ?>">
                            </div>
                            <?= form_error('nama_outlet',  '<small class="text-danger">','</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nama Pengguna</label>
                            <div class="input-group">
                                <select class="form-control" name="id_user" id="form-control">
                                    <option value="<?= $pengguna3['id_user']; ?>"><?= $pengguna3['nama']; ?></option>
                                    <option>--</option>
                                <?php foreach ($pengguna2 as $p) { ?>
                                    <option value="<?= $p['id_user']; ?>"><?= $p['nama']; ?></option>
                                <?php } ; ?>
                                </select>
                            </div>
                            <?= form_error('id_user', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Nomor Telepon</label>
                            <div class="input-group">
                                <input type="number" class="form-control" name="tlp" id="form-control" value="<?= $outlet['tlp']; ?>">
                            </div>
                            <?= form_error('tlp', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group mb-3">
                            <label>Alamat</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="alamat" id="form-control" value="<?= $outlet['alamat']; ?>">
                            </div>
                            <?= form_error('alamat', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <a class="btn btn-primary btn-sm" href="<?= base_url('C_outlet'); ?>"><i class="fas fa-arrow-left"></i>&nbsp; Kembali</a>
                    <button type="reset" class="btn btn-danger btn-sm" value="Reset"><i class="fas fa-sync-alt"></i>&nbsp; Reset</button>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-save"></i>&nbsp; Simpan</button>
                </div>
                <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- content -->
