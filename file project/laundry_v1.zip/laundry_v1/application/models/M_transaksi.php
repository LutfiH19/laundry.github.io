<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_transaksi extends CI_Model
{
    // javascript & no otomatis
        public function showall($tb,$prop) // kilo
        {
            // return $this->db->query("SELECT * FROM tb_paket WHERE id_paket = $_POST[paket]")->row();
            return $this->db->query("SELECT * FROM $tb $prop");
        }
        public function no() // no transaksi otomatis
        {
            return $this->db->query("SELECT max(no_trans) AS kode FROM tb_transaksi");

            // no_trans as kode
            
            // $this->db->SELECT_MAX('no_trans','kode')->FROM('tb_transaksi');
            // return $this->db->get();
        }

    // [ create & update ]
        public function daftarpaket() // looping all data paket
        {
            return $this->db->get('tb_paket')->result_array();
        }
        public function daftarpelanggan() // looping all data member
        {
            return $this->db->get('tb_member')->result_array();
        }

    // akses admin
        // create
            public function add_data()
            {
                $data = 
                [
                'no_trans' => htmlspecialchars($this->input->post('no_trans', true)),
                'operator' => htmlspecialchars($this->input->post('operator', true)),
                'status'   => htmlspecialchars($this->input->post('status',true)),
                'id_member' => ($this->input->post('id_member',true)),
                'id_paket'       => ($this->input->post('id_paket',true)),
                'tgl_transaksi'  => ($this->input->post('tgl_transaksi',true)),
                'jml_kilo'       => ($this->input->post('jml_kilo',true)),
                'totalpure'      => ($this->input->post('totalpure',true)),
                'biaya_tambahan' => ($this->input->post('biaya_tambahan',true)),
                'diskon'         => ($this->input->post('diskon',true)),
                'grand_total'    => ($this->input->post('grand_total',true)),
                'bayar'          => ($this->input->post('bayar',true)),
                'kembalian'      => ($this->input->post('kembalian',true))
                ];
                $tabel_transaksi = $this->db->dbprefix('tb_transaksi');
                // var_dump($data);
                // die;
                if($this->db->insert($tabel_transaksi,$data))
                    {return true;}
                else
                    {return false;}
            }

        // read
            public function daftartransaksi()
            {
                $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama');
                $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
                $this->db->from('tb_transaksi');
                $this->db->order_by('id_transaksi','desc');
                $query = $this->db->get();
                return $query->result();
            }
            
        // update
            public function update($id_transaksi)
            {
                $data = 
                [
                'no_trans' => htmlspecialchars($this->input->post('no_trans', true)),
                'operator' => htmlspecialchars($this->input->post('operator', true)),
                'status'   => htmlspecialchars($this->input->post('status',true)),
                'id_member'      => ($this->input->post('id_member',true)),
                'id_paket'       => ($this->input->post('id_paket',true)),
                'tgl_transaksi'  => ($this->input->post('tgl_transaksi',true)),
                'tgl_ambil'      => ($this->input->post('tgl_ambil',true)),
                'jml_kilo'       => ($this->input->post('jml_kilo',true)),
                'totalpure'      => ($this->input->post('totalpure',true)),
                'biaya_tambahan' => ($this->input->post('biaya_tambahan',true)),
                'diskon'         => ($this->input->post('diskon',true)),
                'grand_total'    => ($this->input->post('grand_total',true)),
                'bayar'          => ($this->input->post('bayar',true)),
                'kembalian'      => ($this->input->post('kembalian',true))
                ];
                $tabel_transaksi = $this->db->dbprefix('tb_transaksi');
                $this->db->where('id_transaksi',$id_transaksi);
                // var_dump($data);
                // die;
                if($this->db->update($tabel_transaksi,$data))
                    {return true;}
                else
                    {return false;}
            }

            public function edit($id_transaksi)
            {
                $this->db->where('id_transaksi',$id_transaksi);
                return $this->db->get('tb_transaksi')->row_array();
            }

            public function daftarpaket2($id_transaksi) // show data paket only 1 / with id
            {
                $this->db->select('tb_transaksi.*, tb_paket.id_paket, tb_paket.nama_paket, tb_paket.harga');
                $this->db->join('tb_paket', 'tb_transaksi.id_paket = tb_paket.id_paket');
                $this->db->from('tb_transaksi');
                $this->db->where('id_transaksi',$id_transaksi);
                $query = $this->db->get();
                return $query->row_array();
            }
            public function daftarpelanggan2($id_transaksi) // show data member only 1 / with id
            {
                $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama, tb_member.alamat, tb_member.tlp');
                $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
                $this->db->from('tb_transaksi');
                $this->db->where('id_transaksi',$id_transaksi);
                $query = $this->db->get();
                return $query->row_array();
            }





    // akses kasir
        // create
            public function add_dataK()
            {
                $data = 
                [
                'no_trans' => htmlspecialchars($this->input->post('no_trans', true)),
                'operator' => htmlspecialchars($this->input->post('operator', true)),
                'status'   => htmlspecialchars($this->input->post('status',true)),
                'id_member' => ($this->input->post('id_member',true)),
                'id_paket'       => ($this->input->post('id_paket',true)),
                'tgl_transaksi'  => ($this->input->post('tgl_transaksi',true)),
                'jml_kilo'       => ($this->input->post('jml_kilo',true)),
                'totalpure'      => ($this->input->post('totalpure',true)),
                'biaya_tambahan' => ($this->input->post('biaya_tambahan',true)),
                'diskon'         => ($this->input->post('diskon',true)),
                'grand_total'    => ($this->input->post('grand_total',true)),
                'bayar'          => ($this->input->post('bayar',true)),
                'kembalian'      => ($this->input->post('kembalian',true))
                ];
                $tabel_transaksi = $this->db->dbprefix('tb_transaksi');
                // var_dump($data);
                // die;
                if($this->db->insert($tabel_transaksi,$data))
                    {return true;}
                else
                    {return false;}
            }

        // read
            public function daftartransaksiK()
            {
                $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama');
                $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
                $this->db->from('tb_transaksi');
                $this->db->order_by('id_transaksi','desc');
                $query = $this->db->get();
                return $query->result();
            }

        // update
            public function updateK($id_transaksi)
            {
                $data = 
                [
                'no_trans' => htmlspecialchars($this->input->post('no_trans', true)),
                'operator' => htmlspecialchars($this->input->post('operator', true)),
                'status'   => htmlspecialchars($this->input->post('status',true)),
                'id_member'      => ($this->input->post('id_member',true)),
                'id_paket'       => ($this->input->post('id_paket',true)),
                'tgl_transaksi'  => ($this->input->post('tgl_transaksi',true)),
                'tgl_ambil'      => ($this->input->post('tgl_ambil',true)),
                'jml_kilo'       => ($this->input->post('jml_kilo',true)),
                'totalpure'      => ($this->input->post('totalpure',true)),
                'biaya_tambahan' => ($this->input->post('biaya_tambahan',true)),
                'diskon'         => ($this->input->post('diskon',true)),
                'grand_total'    => ($this->input->post('grand_total',true)),
                'bayar'          => ($this->input->post('bayar',true)),
                'kembalian'      => ($this->input->post('kembalian',true))
                ];
                $tabel_transaksi = $this->db->dbprefix('tb_transaksi');
                $this->db->where('id_transaksi',$id_transaksi);
                // var_dump($data);
                // die;
                if($this->db->update($tabel_transaksi,$data))
                    {return true;}
                else
                    {return false;}
            }

            public function editK($id_transaksi)
            {
                $this->db->where('id_transaksi',$id_transaksi);
                return $this->db->get('tb_transaksi')->row_array();
            }

            public function daftarpaket2K($id_transaksi) // show data paket only 1 / with id
            {
                $this->db->select('tb_transaksi.*, tb_paket.id_paket, tb_paket.nama_paket, tb_paket.harga');
                $this->db->join('tb_paket', 'tb_transaksi.id_paket = tb_paket.id_paket');
                $this->db->from('tb_transaksi');
                $this->db->where('id_transaksi',$id_transaksi);
                $query = $this->db->get();
                return $query->row_array();
            }
            public function daftarpelanggan2K($id_transaksi) // show data member only 1 / with id
            {
                $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama, tb_member.alamat, tb_member.tlp');
                $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
                $this->db->from('tb_transaksi');
                $this->db->where('id_transaksi',$id_transaksi);
                $query = $this->db->get();
                return $query->row_array();
            }




}
