<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_paket extends CI_Model
{
    // akses admin
        // create 
            public function add_data()
            {
                $data = 
                [
                'nama_paket' => htmlspecialchars($this->input->post('nama_paket', true)),
                'jenis_paket' => ($this->input->post('jenis_paket',true)),
                'harga' => ($this->input->post('harga',true)),
                'id_outlet' => ($this->input->post('id_outlet',true))
                ];
                $tabel_paket = $this->db->dbprefix('tb_paket');
                if($this->db->insert($tabel_paket,$data))
                    {return true;}
                else
                    {return false;}
            }
            public function daftaroutlet()
            {
                return $this->db->get('tb_outlet')->result();
            }

        // read 
            public function tampil_data()
            {
                $this->db->select('tb_paket.*, tb_outlet.id_outlet, tb_outlet.nama_outlet');
                $this->db->join('tb_outlet', 'tb_paket.id_outlet = tb_outlet.id_outlet');
                $this->db->from('tb_paket');
                $this->db->order_by('id_paket','desc');
                $query = $this->db->get();
                return $query->result();
            }

        // update 
            public function update($id_paket)
            {
                $data = 
                [
                'nama_paket' => htmlspecialchars($this->input->post('nama_paket', true)),
                'jenis_paket' => ($this->input->post('jenis_paket',true)),
                'harga' => ($this->input->post('harga',true)),
                'id_outlet' => ($this->input->post('id_outlet',true))
                ];
                $tabel_paket = $this->db->dbprefix('tb_paket');
                $this->db->where('id_paket',$id_paket);
                if($this->db->update($tabel_paket,$data))
                    {return true;}
                else
                    {return false;}
            }
            public function edit($id_paket)
            {
                $this->db->where('id_paket',$id_paket);
                return $this->db->get('tb_paket')->row_array();
            }
            public function daftaroutlet2()
            {
                return $this->db->get('tb_outlet')->result_array();
            }
            public function daftaroutlet3($id_paket)
            {
                $this->db->select('tb_paket.*, tb_outlet.id_outlet, tb_outlet.nama_outlet');
                $this->db->join('tb_outlet', 'tb_paket.id_outlet = tb_outlet.id_outlet');
                $this->db->from('tb_paket');
                $this->db->where('id_paket',$id_paket);
                $query = $this->db->get();
                return $query->row_array();
            }

        // delete 
            public function dropped($id_paket)
            {
                $this->db->where('id_paket', $id_paket);
                if($this->db->delete('tb_paket'))
                    {return true;}
                else
                    {return false;}
            }

}