<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_pelanggan extends CI_Model
{
    // akses admin
        // create
        public function add_data()
        {
            $data = 
            [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat',true)),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin',true)),
                'tlp' => ($this->input->post('tlp',true))
            ];
            $tabel_member = $this->db->dbprefix('tb_member');
            if($this->db->insert($tabel_member,$data))
                {return true;}
            else
                {return false;}
        }

        // read
        public function tampil_data()
        {
            $this->db->order_by('id_member','desc');
            return $this->db->get('tb_member')->result();
        }

        // update 
        public function update($id_member)
        {
            $data = 
            [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat',true)),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin',true)),
                'tlp' => ($this->input->post('tlp',true))
            ];
            $tabel_member = $this->db->dbprefix('tb_member');
            $this->db->where('id_member',$id_member);
            if($this->db->update($tabel_member,$data))
                {return true;}
            else
                {return false;}
        }
        public function edit($id_member)
        {
            $this->db->where('id_member',$id_member);
            return $this->db->get('tb_member')->row_array();
        }

        // delete
        public function dropped($id_member)
        {
            $this->db->where('id_member', $id_member);
            if($this->db->delete('tb_member'))
                {return true;}
            else
                {return false;}
        }



    // akses kasir
        // create
        public function add_data2()
        {
            $data = 
            [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat',true)),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin',true)),
                'tlp' => ($this->input->post('tlp',true))
            ];
            $tabel_member = $this->db->dbprefix('tb_member');
            if($this->db->insert($tabel_member,$data))
                {return true;}
            else
                {return false;}
        }

        // read
        public function tampil_data2()
        {
            $this->db->order_by('id_member','desc');
            return $this->db->get('tb_member')->result();
        }

        // update 
        public function update2($id_member)
        {
            $data = 
            [
                'nama' => htmlspecialchars($this->input->post('nama', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat',true)),
                'jenis_kelamin' => htmlspecialchars($this->input->post('jenis_kelamin',true)),
                'tlp' => ($this->input->post('tlp',true))
            ];
            $tabel_member = $this->db->dbprefix('tb_member');
            $this->db->where('id_member',$id_member);
            if($this->db->update($tabel_member,$data))
                {return true;}
            else
                {return false;}
        }
        public function edit2($id_member)
        {
            $this->db->where('id_member',$id_member);
            return $this->db->get('tb_member')->row_array();
        }

        // delete
        public function dropped2($id_member)
        {
            $this->db->where('id_member', $id_member);
            if($this->db->delete('tb_member'))
                {return true;}
            else
                {return false;}
        }


}