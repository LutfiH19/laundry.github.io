<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_beranda extends CI_Model
{
    // akses admin
       //  count outlet
            public function j_outlet()
            {   
                $query = $this->db->get('tb_outlet');
                if($query->num_rows()>0)
                {
                return $query->num_rows(); // hitung total data record/baris
                }
                else
                {
                return 0;
                }
            }
       //  count pelanggan
            public function j_pelanggan()
            {   
                $query = $this->db->get('tb_member');
                if($query->num_rows()>0)
                {
                return $query->num_rows();
                }
                else
                {
                return 0;
                }
            }
       //  count pelanggan
            public function j_transaksi()
            {   
                $query = $this->db->get('tb_transaksi');
                if($query->num_rows()>0)
                {
                return $query->num_rows();
                }
                else
                {
                return 0;
                }
            }
       //  sum transaksi
            public function t_penghasilan()
            {
                $this->db->select_sum('grand_total'); // menjumlahkan nilai data di field 
                // $this->db->where('status', 'diambil');
                $query = $this->db->get_where('tb_transaksi',['status' => 'diambil']);
                if($query->num_rows()>0)
                {
                    return $query->row()->grand_total;
                }
                else
                {
                    return 0;
                }
            }
       //  tabel transasksi
            public function daftartransaksi()
            {
                $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama');
                $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
                $this->db->from('tb_transaksi');
                $this->db->order_by('id_transaksi','desc');
                $query = $this->db->get();
                return $query->result();
            }


    // akses owner

}
