<?php
defined('BASEPATH') or exit('No direct script access allowed');
class M_laporan extends CI_Model
{
    // akses admin
        // tabel laporan
            public function daftartransaksi()
            {
                $this->db->select('tb_transaksi.*, tb_member.id_member, tb_member.nama');
                $this->db->join('tb_member', 'tb_transaksi.id_member = tb_member.id_member');
                $this->db->from('tb_transaksi');
                $this->db->order_by('id_transaksi','desc');
                $query = $this->db->get();
                return $query->result();
            }


}
