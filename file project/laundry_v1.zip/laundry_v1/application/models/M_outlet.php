<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class M_outlet extends CI_Model
{
    // akses admin
        // create 
            public function add_data()
            {
                $data = 
                [
                'nama_outlet' => htmlspecialchars($this->input->post('nama_outlet', true)),
                'id_user' => ($this->input->post('id_user', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat',true)),
                'tlp' => ($this->input->post('tlp',true))
                ];
                $tabel_outlet = $this->db->dbprefix('tb_outlet');
                if($this->db->insert($tabel_outlet,$data))
                    {return true;}
                else
                    {return false;}
            }
            public function daftarpengguna() // looping daftar pengguna
            {
                $this->db->where_in('role', ['Kasir']); // filter admin,owner  
                return $this->db->get('tb_user')->result();
            }

        // read 
            public function tampil_data()
            {
                $this->db->select('tb_outlet.*, tb_user.id_user, tb_user.nama');
                $this->db->join('tb_user', 'tb_outlet.id_user = tb_user.id_user');
                $this->db->from('tb_outlet');
                $this->db->where_in('role', ['Kasir']); // filter admin  // ['Kasir','Owner']
                $this->db->order_by('id_outlet','desc');
                $query = $this->db->get();
                return $query->result();
            }

        // update 
            public function update($id_outlet)
            {
                $data = 
                [
                'nama_outlet' => htmlspecialchars($this->input->post('nama_outlet', true)),
                'id_user' => ($this->input->post('id_user', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat',true)),
                'tlp' => ($this->input->post('tlp',true))
                ];
                $tabel_outlet = $this->db->dbprefix('tb_outlet');
                $this->db->where('id_outlet',$id_outlet);
                if($this->db->update($tabel_outlet,$data))
                    {return true;}
                else
                    {return false;}
            }
            public function edit($id_outlet)
            {
                $this->db->where('id_outlet',$id_outlet);
                return $this->db->get('tb_outlet')->row_array();
            }
            public function daftarpengguna2() // looping daftar pengguna
            {
                $this->db->where_in('role', ['Kasir']); // filter admin,owner
                return $this->db->get('tb_user')->result_array();
            }
            public function daftarpengguna3($id_outlet) // looping daftar pengguna dengan id
            {
                $this->db->select('tb_outlet.*, tb_user.id_user, tb_user.nama');
                $this->db->join('tb_user', 'tb_outlet.id_user = tb_user.id_user');
                $this->db->from('tb_outlet');
                $this->db->where_in('role', ['Kasir']); // filter admin,owner
                $this->db->where('id_outlet',$id_outlet);
                $query = $this->db->get();
                return $query->row_array();
            }

        // delete 
            public function dropped($id_outlet)
            {
                $this->db->where('id_outlet', $id_outlet);
                if($this->db->delete('tb_outlet'))
                    {return true;}
                else
                    {return false;}
            }


}